"""
Embeddings über die SAIA-API (GWDG / Academic Cloud / KISSKI).

Endpunkt (OpenAI-kompatibel):
    POST https://chat-ai.academiccloud.de/v1/embeddings
    Header: Authorization: Bearer <api_key>
    Body:   {"input": [...], "model": "...", "encoding_format": "float"}

Verfügbare Embedding-Modelle laut GWDG-Doku:
    e5-mistral-7b-instruct
    multilingual-e5-large-instruct
    qwen3-embedding-4b

Alle drei sind instruktionssensitiv: Anfragen (Claims) bekommen ein
"Instruct:/Query:"-Präfix, Dokumente (Artikelsätze) bleiben roh — das ist
die von den E5-/Qwen-Autoren empfohlene asymmetrische Verwendung.
"""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request

BASE_URL = "https://chat-ai.academiccloud.de/v1/embeddings"

MODELS = (
    "multilingual-e5-large-instruct",
    "qwen3-embedding-4b",
    "e5-mistral-7b-instruct",
)

_TASK = ("Given a claim from a German audio transcript, retrieve the "
         "sentence from the original German news article that supports it")

_BATCH = 32
_TIMEOUT = 180


class SaiaError(RuntimeError):
    pass


def _request(payload: dict, api_key: str) -> dict:
    req = urllib.request.Request(
        BASE_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = ""
        try:
            body = e.read().decode("utf-8", "replace")[:300]
        except Exception:
            pass
        hint = ""
        if e.code == 401:
            hint = " — API-Key prüfen (KISSKI LLM Service)."
        elif e.code == 404:
            hint = " — Modellname prüfen (siehe /v1/models)."
        elif e.code == 429:
            hint = " — Ratelimit erreicht, kurz warten."
        raise SaiaError(f"SAIA HTTP {e.code}{hint} {body}") from None
    except urllib.error.URLError as e:
        raise SaiaError(f"SAIA nicht erreichbar: {e.reason}") from None


def embed(texts: list[str], model: str, api_key: str | None = None,
          is_query: bool = False) -> list[list[float]]:
    """Embeddings für eine Textliste, in Eingabereihenfolge."""
    key = api_key or os.environ.get("SAIA_API_KEY", "")
    if not key:
        raise SaiaError("Kein API-Key: im Formular eintragen oder "
                        "SAIA_API_KEY als Umgebungsvariable setzen.")
    if model not in MODELS:
        raise SaiaError(f"Unbekanntes Embedding-Modell: {model!r}")

    prepped = ([f"Instruct: {_TASK}\nQuery: {t}" for t in texts]
               if is_query else list(texts))

    out: list[list[float]] = []
    for i in range(0, len(prepped), _BATCH):
        chunk = prepped[i:i + _BATCH]
        res = _request({"input": chunk, "model": model,
                        "encoding_format": "float"}, key)
        data = res.get("data")
        if not data or len(data) != len(chunk):
            raise SaiaError("Unerwartete Antwortstruktur der Embeddings-API.")
        data.sort(key=lambda d: d.get("index", 0))
        out.extend(d["embedding"] for d in data)
    return out
