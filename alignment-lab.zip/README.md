# Articly Alignment Lab — Stufe 0–2

Testwerkzeug für die Informationszuordnung Transkript ⇄ Originalartikel.
Eigenes Paar einfügen, analysieren, im Split-View prüfen: Welche Aussage
stammt woher, wo weichen Zahlen ab, was ist unbelegt.

## Start

Keine Installation, keine Abhängigkeiten — nur Python ≥ 3.10:

```bash
python3 app.py            # http://127.0.0.1:8765
python3 app.py 8080       # anderer Port
```

Browser öffnen, Artikel + Transkript einfügen (oder „Beispiel laden"),
Modell wählen, **Analysieren**. Strg+Enter in den Textfeldern startet
ebenfalls.

## Embeddings (Stufe 2)

Läuft über die SAIA-API der GWDG (Academic Cloud / KISSKI),
OpenAI-kompatibler Endpunkt `https://chat-ai.academiccloud.de/v1/embeddings`.

- API-Key über den [KISSKI LLM Service](https://kisski.gwdg.de/en/leistungen/2-02-llm-service) buchen („Book"),
  dieselbe Mailadresse wie im Academic-Cloud-Konto verwenden.
- Key im Formular eintragen (bleibt im Browser-localStorage) **oder**
  `export SAIA_API_KEY=…` vor dem Start.
- Modelle: `multilingual-e5-large-instruct` (schnell, guter Default),
  `qwen3-embedding-4b`, `e5-mistral-7b-instruct` (größer, langsamer).
- Ohne Key: Option „ohne — nur Stufe 0+1" nutzt rein lexikalische
  Zuordnung, komplett offline. Für zahlenlastige Lokalnachrichten
  bereits erstaunlich brauchbar.

Claims werden mit Instruct-Präfix als Queries eingebettet, Artikelsätze
roh als Dokumente (asymmetrische E5-/Qwen-Konvention). Die Kosinuswerte
werden robust normalisiert (P10–P95), weil E5-Modelle auch für
Unverwandtes hohe Rohwerte liefern.

## Was die Stufen tun

| Stufe | Signal | Ergebnis |
|---|---|---|
| 0 | Deutsche Zahlwörter → Normform („sechs Komma acht Millionen Euro" → `6800000 EUR`), Geld/Prozent/Jahre/Verhältnisse/Namen | Anker-Boni, **Zahlkonflikt**- und **Zahl-unbelegt**-Flags |
| 1 | Char-3/4-Gramm-TF-IDF auf zahlnormalisiertem Text + Positionsprior | Kandidatenranking, Margin |
| 2 | SAIA-Embeddings + Score-Fusion + Satzfenster | robuste Zuordnung, **aggregiert**-Erkennung (benachbart und über Zahlen-Anker auch nicht-benachbart) |

Relationen: `direkt`, `aggregiert`, `keine_quelle`. Claims zwischen den
Schwellen bleiben `direkt` mit niedriger Confidence und der Notiz
„Unter der Direkt-Schwelle" — sichtbar über den Margin-Chip.

## Im Viewer

- Chips oben: Zahlkonflikt · Zahl unbelegt · ohne Quelle · Margin < 0,10 · Artikel ungenutzt
- Inspector zeigt zusätzlich die Roh-Scores (top/lex/emb/anker) je Claim — zum Schwellen-Tuning
- „Teilspanne" markiert bei Anker-Treffern exakt die Zahlregion im Artikel
- Export erzeugt JSON, das unverändert im ursprünglichen
  Split-View-Prototyp ladbar ist (gleiches Schema)

## Tuning

Alle Schwellen und Gewichte in `pipeline.py` → `CFG` (Fusionsgewichte,
`t_direct`/`t_none`, Aggregations-Deltas, Anker-Boni). Sinnvoller
Workflow: 30–50 Paare durchschieben, Fälle mit Margin < 0,10 ansehen,
Schwellen nachziehen.

## Grenzen (bewusst)

- `inferiert` wird nicht vergeben — dafür braucht es NLI (Stufe 3).
- Claims = Transkriptsätze; feineres Claim-Splitting kommt später.
- Teilspannen nur über Zahlen-Anker, kein Token-Alignment.
- Personenprüfung ist heuristisch (kapitalisierte Namensfolgen).

## Dateien

```
app.py              Server (nur Standardbibliothek), /api/align
pipeline.py         Stufen 0–2: Segmentierung, Fusion, Entscheidung
german_numbers.py   Zahlwort-Parser + Entity-Extraktion
saia.py             SAIA-Embeddings-Client
static/index.html   Split-View-Frontend mit Eingabe-Panel
build_frontend.py   erzeugt index.html aus dem Original-Prototyp
```
