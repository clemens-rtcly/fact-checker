"""
Alignment-Pipeline, Stufen 0–2.

  Stufe 0  Normalisierung & Entity-Anker (german_numbers) + Zahlkonflikt-Prüfung
  Stufe 1  Lexikalisches Alignment: Char-n-Gramm-TF-IDF + Positionsprior + Margin
  Stufe 2  Embeddings (SAIA, optional) + Score-Fusion + Aggregations-Erkennung

Ausgabe: JSON exakt im Schema des Split-View-Prototyps
(article.sentences, transcript.claims mit relation/sources/confidence/
margin/entities/flags/note).

Keine externen Abhängigkeiten. Embeddings werden als Funktion injiziert.
"""
from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import dataclass

from german_numbers import Entity, extract_entities, normalize_numbers

# ------------------------------------------------------------- Konfiguration

CFG = {
    # Fusionsgewichte (werden ohne Embeddings automatisch renormalisiert)
    "w_emb": 0.50,
    "w_lex": 0.38,
    "w_pos": 0.12,
    # Anker-Boni (additiv, gedeckelt)
    "anchor_unique": 0.30,   # numerischer Anker, eindeutig im Artikel
    "anchor_multi": 0.12,    # numerischer Anker, 2–3 Fundstellen
    "anchor_name": 0.10,     # seltener Eigenname
    "anchor_cap": 0.38,
    # Entscheidungsschwellen auf dem fusionierten Score
    "t_direct": 0.58,
    "t_none": 0.34,
    # Aggregation: Fenster muss Einzelsatz deutlich schlagen
    "agg_delta": 0.05,
    "agg_member_min": 0.28,
    "agg_min_claim_len": 70,
    # Redundante Fundstellen
    "redundant_delta": 0.07,
}


# ------------------------------------------------------------- Segmentierung

_ABBREV = {
    "z.b", "bzw", "ca", "dr", "prof", "mio", "mrd", "nr", "u.a", "d.h",
    "o.ä", "o.a", "vgl", "ggf", "inkl", "evtl", "usw", "str", "abs", "art",
    "etc", "sog", "u.u", "v.a", "bspw", "geb", "st", "hr", "fr", "min",
    "max", "tel", "co", "jh", "jhd", "s", "vgl",
}

_SENT_END = re.compile(r"[.!?…]+[»«\"'\u201c\u201d\u201e)\]]*")


@dataclass
class Sent:
    id: str
    start: int
    end: int
    text: str
    paragraph: int
    block: str


def _split_sentences_in(text: str, p_start: int, p_end: int) -> list[tuple[int, int]]:
    """Satzgrenzen innerhalb eines Absatzes, als absolute Offsets."""
    out = []
    seg_start = p_start
    for m in _SENT_END.finditer(text, p_start, p_end):
        end = m.end()
        # Folgekontext prüfen: nach Satzende kommt Leerraum + Großbuchstabe/Ziffer/Anführung
        rest = text[end:p_end]
        nxt = rest.lstrip()
        if nxt and not re.match(r"[A-ZÄÖÜ0-9\u201e\u201c\"'«»(]", nxt):
            continue
        # Wort vor dem Punkt: Abkürzung oder kurze Ordnungszahl -> keine Grenze
        before = text[seg_start:m.start()]
        wm = re.search(r"([A-Za-zÄÖÜäöüß.]+|\d+)$", before)
        if wm:
            w = wm.group(1).lower().rstrip(".")
            if w in _ABBREV:
                continue
            if w.isdigit() and len(w) <= 2 and "." in m.group(0):
                continue  # "3. Platz", "2. Januar"
        out.append((seg_start, end))
        seg_start = end
        while seg_start < p_end and text[seg_start].isspace():
            seg_start += 1
    if seg_start < p_end and text[seg_start:p_end].strip():
        out.append((seg_start, p_end))
    # Whitespace an den Rändern abschneiden
    trimmed = []
    for s, e in out:
        while s < e and text[s].isspace():
            s += 1
        while e > s and text[e - 1].isspace():
            e -= 1
        if e > s:
            trimmed.append((s, e))
    return trimmed


def segment(text: str, kind: str, id_prefix: str) -> list[Sent]:
    """Absätze + Sätze mit exakten Zeichen-Offsets. kind: 'article'|'transcript'."""
    sents: list[Sent] = []
    para_idx = 0
    counter = 1
    for pm in re.finditer(r"[^\n]+(?:\n(?!\n)[^\n]*)*", text):
        p_start, p_end = pm.start(), pm.end()
        for s, e in _split_sentences_in(text, p_start, p_end):
            if kind == "article":
                if para_idx == 0:
                    block = "headline"
                elif para_idx == 1:
                    block = "lead"
                else:
                    block = "body"
            else:
                block = "body"
            sents.append(Sent(f"{id_prefix}{counter}", s, e, text[s:e], para_idx, block))
            counter += 1
        para_idx += 1
    return sents


# ------------------------------------------- Stufe 1: Char-n-Gramm-TF-IDF

_WS = re.compile(r"\s+")


def _prep(text: str) -> str:
    t = normalize_numbers(text).lower()
    t = re.sub(r"[^\wäöüß ]", " ", t)
    return " " + _WS.sub(" ", t).strip() + " "


def _ngrams(text: str, ns=(3, 4)) -> Counter:
    c: Counter = Counter()
    for n in ns:
        for i in range(len(text) - n + 1):
            c[text[i:i + n]] += 1
    return c


class TfIdf:
    def __init__(self, docs: list[str]):
        self.tfs = [_ngrams(_prep(d)) for d in docs]
        df: Counter = Counter()
        for tf in self.tfs:
            df.update(tf.keys())
        n_docs = max(len(docs), 1)
        self.idf = {g: math.log((1 + n_docs) / (1 + d)) + 1 for g, d in df.items()}

    def vec(self, text: str) -> dict[str, float]:
        tf = _ngrams(_prep(text))
        v = {g: (1 + math.log(c)) * self.idf.get(g, self.idf_default())
             for g, c in tf.items()}
        norm = math.sqrt(sum(x * x for x in v.values())) or 1.0
        return {g: x / norm for g, x in v.items()}

    def idf_default(self) -> float:
        return max(self.idf.values()) if self.idf else 1.0


def _cos_sparse(a: dict[str, float], b: dict[str, float]) -> float:
    if len(b) < len(a):
        a, b = b, a
    return sum(x * b.get(g, 0.0) for g, x in a.items())


def _cos_dense(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a)) or 1.0
    nb = math.sqrt(sum(x * x for x in b)) or 1.0
    return dot / (na * nb)


# ------------------------------------------------------------------ Pipeline

def _numeric(ents: list[Entity]) -> list[Entity]:
    return [e for e in ents if e.type in ("geld", "prozent", "zahl", "datum")]


def _values_equal(a: Entity, b: Entity) -> bool:
    if isinstance(a.value, str) or isinstance(b.value, str):
        return str(a.value) == str(b.value)
    if a.type != b.type and {a.type, b.type} != {"zahl", "datum"}:
        return False
    return abs(float(a.value) - float(b.value)) < 1e-6


def _normalize_matrix(rows: list[list[float]]) -> list[list[float]]:
    """Robuste Min-Max-Normalisierung (P10..P95) über alle Paare.

    Nötig, weil E5-artige Embeddings auch für unverwandte Paare hohe
    Kosinuswerte liefern (Floor ~0,7)."""
    flat = sorted(v for row in rows for v in row)
    if not flat:
        return rows
    lo = flat[int(0.10 * (len(flat) - 1))]
    hi = flat[int(0.95 * (len(flat) - 1))]
    span = (hi - lo) or 1e-9
    return [[min(1.0, max(0.0, (v - lo) / span)) for v in row] for row in rows]


def align(article_text: str, transcript_text: str,
          embed_fn=None, model_label: str = "ohne Embeddings") -> dict:
    """Hauptfunktion. embed_fn(texts, is_query) -> list[list[float]] | None."""
    art_sents = segment(article_text, "article", "s")
    claims_raw = segment(transcript_text, "transcript", "c")

    art_ents = [extract_entities(s.text) for s in art_sents]
    # Offsets der Satz-Entities auf Dokumentkoordinaten heben
    for s, es in zip(art_sents, art_ents):
        for e in es:
            e.start += s.start
            e.end += s.start
    claim_ents = [extract_entities(c.text) for c in claims_raw]
    for c, es in zip(claims_raw, claim_ents):
        for e in es:
            e.start += c.start
            e.end += c.start

    m, n = len(claims_raw), len(art_sents)
    if m == 0 or n == 0:
        return _assemble(article_text, transcript_text, art_sents, [], model_label)

    # ---------------- Stufe 1: lexikalische Matrix
    tfidf = TfIdf([s.text for s in art_sents] + [c.text for c in claims_raw])
    art_vecs = [tfidf.vec(s.text) for s in art_sents]
    claim_vecs = [tfidf.vec(c.text) for c in claims_raw]
    lex = [[_cos_sparse(cv, av) for av in art_vecs] for cv in claim_vecs]

    # Fenster benachbarter Sätze (gleicher Absatz) für Aggregation
    windows: list[tuple[list[int], str]] = []
    for i in range(n - 1):
        windows.append(([i, i + 1],
                        art_sents[i].text + " " + art_sents[i + 1].text))
    win_vecs = [tfidf.vec(w[1]) for w in windows]
    lex_win = [[_cos_sparse(cv, wv) for wv in win_vecs] for cv in claim_vecs]

    # ---------------- Stufe 2: Embeddings (optional)
    emb = emb_win = None
    if embed_fn is not None:
        doc_texts = [s.text for s in art_sents] + [w[1] for w in windows]
        doc_vecs = embed_fn(doc_texts, is_query=False)
        q_vecs = embed_fn([c.text for c in claims_raw], is_query=True)
        if doc_vecs and q_vecs:
            sent_vecs, w_vecs = doc_vecs[:n], doc_vecs[n:]
            emb_raw = [[_cos_dense(q, d) for d in sent_vecs] for q in q_vecs]
            emb = _normalize_matrix(emb_raw)
            if windows:
                # gleiche Normalisierung (gleiche Verteilung) getrennt berechnet
                emb_win = _normalize_matrix(
                    [[_cos_dense(q, d) for d in w_vecs] for q in q_vecs])

    # ---------------- Stufe 0: Anker
    anchor = [[0.0] * n for _ in range(m)]
    anchor_notes: list[list[str]] = [[] for _ in range(m)]
    for ci, ents in enumerate(claim_ents):
        for e in _numeric(ents):
            hits = [si for si, ses in enumerate(art_ents)
                    if any(_values_equal(e, se) for se in _numeric(ses))]
            bonus = (CFG["anchor_unique"] if len(hits) == 1
                     else CFG["anchor_multi"] if 2 <= len(hits) <= 3 else 0.0)
            for si in hits:
                anchor[ci][si] += bonus
            if len(hits) == 1:
                anchor_notes[ci].append(
                    f"Anker {e.norm} eindeutig in {art_sents[hits[0]].id}")
        for e in ents:
            if e.type != "person":
                continue
            key = str(e.value)
            hits = [si for si, s in enumerate(art_sents)
                    if key in s.text.lower()]
            if 1 <= len(hits) <= 2:
                for si in hits:
                    anchor[ci][si] += CFG["anchor_name"]
    anchor = [[min(v, CFG["anchor_cap"]) for v in row] for row in anchor]

    # ---------------- Fusion
    if emb is not None:
        w_e, w_l, w_p = CFG["w_emb"], CFG["w_lex"], CFG["w_pos"]
    else:
        tot = CFG["w_lex"] + CFG["w_pos"]
        w_e, w_l, w_p = 0.0, CFG["w_lex"] / tot * 0.88, CFG["w_pos"] / tot * 0.88

    def fused_at(ci: int, si: int) -> float:
        pos = 1.0 - abs(si / max(n - 1, 1) - ci / max(m - 1, 1))
        s = w_l * lex[ci][si] + w_p * pos + anchor[ci][si]
        if emb is not None:
            s += w_e * emb[ci][si]
        return min(s, 1.0)

    fused = [[fused_at(ci, si) for si in range(n)] for ci in range(m)]

    def fused_win(ci: int, wi: int) -> float:
        s = w_l * lex_win[ci][wi]
        if emb_win is not None:
            s += w_e * emb_win[ci][wi]
        # Anker/Position der Mitglieder anteilig
        mem = windows[wi][0]
        s += max(anchor[ci][si] for si in mem)
        pos = 1.0 - abs((sum(mem) / len(mem)) / max(n - 1, 1) - ci / max(m - 1, 1))
        s += w_p * pos
        return min(s, 1.0)

    # ---------------- Entscheidungen pro Claim
    claims_json = []
    for ci, c in enumerate(claims_raw):
        row = fused[ci]
        order = sorted(range(n), key=lambda si: -row[si])
        s1, si1 = row[order[0]], order[0]
        s2 = row[order[1]] if n > 1 else 0.0
        margin = round(max(s1 - s2, 0.0), 2)
        note_parts = list(anchor_notes[ci])
        flags: list[str] = []

        # Aggregations-Kandidat?
        agg = None
        if windows and len(c.text) >= CFG["agg_min_claim_len"]:
            worder = sorted(range(len(windows)), key=lambda wi: -fused_win(ci, wi))
            wbest = worder[0]
            wscore = fused_win(ci, wbest)
            mem = windows[wbest][0]
            if (wscore >= s1 + CFG["agg_delta"] and si1 in mem
                    and all(row[si] >= CFG["agg_member_min"] for si in mem)):
                agg = (mem, wscore)

        if agg is not None:
            mem, wscore = agg
            relation = "aggregiert"
            srcs = mem
            conf = round(min(0.95, 0.45 + (wscore - CFG["t_none"]) * 0.9), 2)
            note_parts.append(
                "Verdichtet aus " + " + ".join(art_sents[si].id for si in mem)
                + " (Fenster schlägt Einzelsatz).")
        elif s1 >= CFG["t_direct"]:
            relation = "direkt"
            srcs = [si1]
            for si in order[1:]:
                if row[si] >= max(CFG["t_direct"], s1 - CFG["redundant_delta"]):
                    srcs.append(si)
                else:
                    break
            conf = round(min(0.98, 0.55 + (s1 - CFG["t_direct"]) * 1.4
                             + (0.06 if anchor[ci][si1] > 0 else 0.0)), 2)
        elif s1 >= CFG["t_none"]:
            relation = "direkt"
            srcs = [si1]
            conf = round(0.35 + (s1 - CFG["t_none"])
                         / (CFG["t_direct"] - CFG["t_none"]) * 0.28, 2)
            note_parts.append("Unter der Direkt-Schwelle — zur Prüfung empfohlen.")
        else:
            relation = "keine_quelle"
            srcs = []
            conf = round(min(0.97, 0.55 + (CFG["t_none"] - s1) * 2.2), 2)
            note_parts.append("Keine ausreichend ähnliche Stelle im Artikel.")

        # Komplementäre Anker: eindeutige Zahlen-Anker auf Sätze außerhalb
        # der Fundstellen -> der Claim verdichtet nicht-benachbarte Stellen.
        if relation != "keine_quelle":
            covered_vals = {str(ae.value) for si in srcs
                            for ae in _numeric(art_ents[si])}
            extra = []
            for e in _numeric(claim_ents[ci]):
                hits = [si for si, ses in enumerate(art_ents)
                        if any(_values_equal(e, se) for se in _numeric(ses))]
                if len(hits) == 1 and hits[0] not in srcs \
                        and str(e.value) not in covered_vals:
                    extra.append(hits[0])
            if extra:
                srcs = srcs + sorted(set(extra))
                if relation == "direkt" and len(srcs) > 1:
                    relation = "aggregiert"
                    note_parts.append(
                        "Nicht-benachbarte Verdichtung über Zahlen-Anker ("
                        + ", ".join(art_sents[si].id for si in sorted(set(extra)))
                        + ").")

        # ---------------- Stufe 0: Entity-Verifikation gegen die Fundstellen
        ents_json = []
        src_sent_ids = set(srcs)
        near_ids = set(src_sent_ids)
        for si in src_sent_ids:
            near_ids |= {k for k in range(n)
                         if art_sents[k].paragraph == art_sents[si].paragraph}
        all_art_numeric = [(si, e) for si, es in enumerate(art_ents)
                           for e in _numeric(es)]

        for e in _numeric(claim_ents[ci]):
            exact = [si for si, ae in all_art_numeric if _values_equal(e, ae)]
            if exact:
                ents_json.append({"type": e.type, "surface": e.surface,
                                  "norm": str(e.norm), "status": "match"})
                continue
            same_type_near = [(si, ae) for si, ae in all_art_numeric
                              if ae.type == e.type and si in near_ids]
            if not same_type_near:
                same_type_near = [(si, ae) for si, ae in all_art_numeric
                                  if ae.type == e.type]
            if same_type_near and srcs:
                def _dist(pair):
                    si, ae = pair
                    try:
                        return abs(float(ae.value) - float(e.value))
                    except (TypeError, ValueError):
                        return float("inf")
                si, ae = min(same_type_near, key=_dist)
                ents_json.append({
                    "type": e.type, "surface": e.surface, "norm": str(e.norm),
                    "status": "konflikt",
                    "quelle_surface": ae.surface, "quelle_norm": str(ae.norm),
                })
                if "zahlkonflikt" not in flags:
                    flags.append("zahlkonflikt")
                note_parts.append(
                    f"{e.norm} weicht ab — Artikel nennt {ae.norm} "
                    f"({art_sents[si].id}).")
            else:
                ents_json.append({"type": e.type, "surface": e.surface,
                                  "norm": str(e.norm), "status": "unbelegt"})
                if "zahl_unbelegt" not in flags:
                    flags.append("zahl_unbelegt")
                note_parts.append(f"{e.norm} im Artikel nicht auffindbar.")

        for e in claim_ents[ci]:
            if e.type != "person":
                continue
            found = str(e.value) in article_text.lower()
            ents_json.append({"type": "person", "surface": e.surface,
                              "norm": str(e.norm),
                              "status": "match" if found else "unbelegt"})

        # ---------------- Quellspannen (Teilspanne = Ankerregion, sonst Satz)
        sources_json = []
        for rank, si in enumerate(srcs):
            s = art_sents[si]
            span_s, span_e = s.start, s.end
            hits = [ae for ae in _numeric(art_ents[si])
                    if any(_values_equal(ce, ae)
                           for ce in _numeric(claim_ents[ci]))]
            if hits:
                span_s = min(h.start for h in hits)
                span_e = max(h.end for h in hits)
            role = "primaer" if (relation == "aggregiert" or rank == 0) \
                else "redundant"
            sources_json.append({"sentence": s.id, "start": span_s,
                                 "end": span_e, "role": role})

        claims_json.append({
            "id": c.id, "start": c.start, "end": c.end, "text": c.text,
            "relation": relation, "sources": sources_json,
            "confidence": conf, "margin": margin,
            "entities": ents_json, "flags": flags,
            "note": " · ".join(note_parts),
            "scores": {"top": round(s1, 3),
                       "lex": round(lex[ci][si1], 3),
                       "emb": (round(emb[ci][si1], 3) if emb else None),
                       "anchor": round(anchor[ci][si1], 3)},
        })

    return _assemble(article_text, transcript_text, art_sents, claims_json,
                     model_label)


def _assemble(article_text, transcript_text, art_sents, claims_json, model_label):
    title = art_sents[0].text if art_sents else "Eigene Analyse"
    return {
        "meta": {"titel": title, "quelle": "Eigenes Paar",
                 "modell": f"stufe0-2 · {model_label}"},
        "article": {
            "text": article_text,
            "sentences": [{"id": s.id, "start": s.start, "end": s.end,
                           "block": s.block, "paragraph": s.paragraph,
                           "text": s.text} for s in art_sents],
        },
        "transcript": {"text": transcript_text, "claims": claims_json},
    }
